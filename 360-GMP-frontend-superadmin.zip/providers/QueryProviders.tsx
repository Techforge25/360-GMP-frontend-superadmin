"use client";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ReactQueryDevtools } from "@tanstack/react-query-devtools";
import { useState } from "react";
import { ToastContainer } from "react-toastify";

export function QueryProvider({ children }: { children: React.ReactNode }) {
     const [queryClient] = useState(
          () =>
               new QueryClient({
                    defaultOptions: {
                         queries: {
                              staleTime: 60 * 1000,
                              refetchOnWindowFocus: false,
                              retry: 1,
                         },
                    },
               })
     );

     return (
          <QueryClientProvider client={queryClient}>
               {children}
               <ToastContainer />
               {process.env.NODE_ENV === "development" && (
                    <ReactQueryDevtools initialIsOpen={false} />
               )}
          </QueryClientProvider>
     );
}