import { AccountTableRowData } from "@/types";

export const accountTableData: AccountTableRowData[] = [
  {
    id: "1",
    name: "Muhammad Umair",
    email: "umairstack.dev@gmail.com",
    status: "Trial",
    img: "/images/image 95.png",
    createdAt: "2023-01-01",
  },
  {
    id: "2",
    name: "Ali Khan",
    email: "ali@gmail.com",
    status: "Silver",
     img: "/images/image 95.png",
     createdAt: "2023-01-01",
  },
];