import CreateNewRole from "@/app/components/Settings/CreateNewRole";

export default function RolesManagementPage() {

  return (
    <div className="min-h-screen  p-4 antialiased">
      <div className="mx-auto max-w-full">
       <CreateNewRole />
      </div>
    </div>
  );
}