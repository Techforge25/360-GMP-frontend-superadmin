import RolesPermissionsList from "@/app/components/Settings/RolesPermissionsList";


export default function RolesPermissionsPage() {
  return (
    <div className="p-4">
      <RolesPermissionsList />
    </div>
  );
}
