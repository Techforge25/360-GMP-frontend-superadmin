"use client";

import { ReactNode } from "react";

export interface Column<T> {
  key: keyof T | string;
  header: string;
  align?: "left" | "center" | "right";
  render?: (row: T) => ReactNode;
}

interface DataTableProps<T> {
  columns: Column<T>[];
  data: T[];
  rowKey: (row: T) => string;
}

export default function DataTable<T>({
  columns,
  data,
  rowKey,
}: DataTableProps<T>) {
  return (
    <div className="w-full overflow-x-auto rounded-xl border border-border-light bg-surface shadow-sm font-secondary">
      <table className="w-full border-collapse text-sm">
        <thead>
          <tr className="border-b border-border-light bg-surface-muted font-bold text-black uppercase tracking-wide text-[1rem]">
            {columns.map((column) => (
              <th
                key={String(column.key)}
                className={`px-6 py-4 font-medium ${
                  column.align === "center"
                    ? "text-center"
                    : column.align === "right"
                      ? "text-right"
                      : "text-left"
                }`}
              >
                {column.header}
              </th>
            ))}
          </tr>
        </thead>

        <tbody className="divide-y divide-border-light text-text-primary">
          {data.map((row) => (
            <tr
              key={rowKey(row)}
              className="bg-white transition-colors hover:bg-surface-muted/30"
            >
              {columns.map((column) => (
                <td
                  key={String(column.key)}
                  className={`px-6 py-4 ${
                    column.align === "center"
                      ? "text-center"
                      : column.align === "right"
                        ? "text-right"
                        : "text-left"
                  }`}
                >
                  {column.render
                    ? column.render(row)
                    : String(row[column.key as keyof T] ?? "")}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
