"use client";

import { PermissionModule } from "@/types";
import React, { useState } from "react";
import { FiArrowLeft, FiEye, FiEyeOff } from "react-icons/fi";
import { useForm } from "react-hook-form";
import { useRouter } from "next/navigation";

const initialModules: PermissionModule[] = [
  { id: "m1", name: "Dashboard Overview", checked: true },
  { id: "m2", name: "User Management", checked: false },
  { id: "m3", name: "Subscription & Access", checked: false },
  { id: "m4", name: "Marketplace & order logs", checked: false },
  { id: "m5", name: "Financial Hub", checked: false },
  { id: "m6", name: "Communities & Networking", checked: false },
  { id: "m7", name: "Recruitment (Job Board)", checked: false },
];

export default function CreateNewRole() {
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [modules, setModules] = useState<PermissionModule[]>(initialModules);
  const router = useRouter();
  const {
    register,
    formState: { errors },
  } = useForm({
    defaultValues: {
      name: "",
      email: "",
      password: "",
    },
  });

  return (
    <form  className="space-y-6">
      <div>
        <button
          type="button"
          onClick={() => router.back()}
          className="inline-flex items-center gap-2 text-sm font-normal text-black hover:text-[#1E1B4B] transition-colors mb-4 cursor-pointer"
        >
          <FiArrowLeft className="w-4 h-4" />
          Back
        </button>

        <h1 className="text-[1.375rem] font-semibold text-brand-primary">
          Create New Role
        </h1>

        <p className="text-sm text-brand-rating-text-border mt-1">
          Define specialized permissions for team members to manage mobility
          workflows.
        </p>
      </div>

      <div className="bg-white rounded-2xl border border-[#E2E8F0] shadow-sm p-6 space-y-6">
        <h2 className="text-[1.375rem] font-medium text-black">
          Role Configuration
        </h2>

        <div className="space-y-5 max-w-full">
          <div className="space-y-2">
            <label className="text-[14px] font-semibold text-black">
              User Name
            </label>

            <input
              type="text"
              placeholder="e.g john doe"
              {...register("name")}
              className="w-full px-4 py-3 rounded-xl border border-[#E2E8F0] bg-[#FFF] text-sm focus:outline-none focus:ring-2 focus:ring-[#1E1B4B]/10 focus:border-[#1E1B4B]"
            />

            {errors.name && (
              <p className="text-red-500 text-xs">{errors.name.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <label className="text-[14px] font-semibold text-black">
              Email Address
            </label>

            <input
              type="email"
              placeholder="Jane.Doe@360gmp.Com"
              {...register("email")}
              className="w-full px-4 py-3 rounded-xl border border-[#E2E8F0] bg-[#FFF] text-sm focus:outline-none focus:ring-2 focus:ring-[#1E1B4B]/10 focus:border-[#1E1B4B]"
            />

            {errors.email && (
              <p className="text-red-500 text-xs">{errors.email.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <label className="text-[14px] font-semibold text-black">
              Password
            </label>

            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                {...register("password")}
                placeholder="••••••••"
                className="w-full px-4 py-3 rounded-xl border border-[#E2E8F0] bg-[#FFF] text-sm pr-12 focus:outline-none focus:ring-2 focus:ring-[#1E1B4B]/10 focus:border-[#1E1B4B] placeholder:text-black tracking-widest"
              />

              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-black"
              >
                {showPassword ? <FiEye /> : <FiEyeOff />}
              </button>
            </div>

            {errors.password && (
              <p className="text-red-500 text-xs">{errors.password.message}</p>
            )}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-[#E2E8F0] shadow-sm overflow-hidden">
        <div className="bg-setting-background px-6 py-4 border-b border-[#E2E8F0]">
          <h3 className="text-[1.125rem] font-bold tracking-wider text-text-secondary uppercase">
            Access Permissions Matrix
          </h3>
        </div>

        <div className="bg-setting-invite-background px-6 py-3 border-b border-[#E2E8F0]">
          <span className="text-[1rem] font-bold text-text-dark">
            Module Name
          </span>
        </div>

        <div className="divide-y divide-[#E2E8F0]">
          {modules.map((mod) => (
            <div
              key={mod.id}
              className="flex items-center justify-between px-6 py-4 bg-white hover:bg-[#F8FAFC] transition-colors"
            >
              <span className="text-[1rem] font-medium text-text-dark">
                {mod.name}
              </span>

              <input
                type="checkbox"
                checked={mod.checked}
                className="w-5 h-5 accent-[#0066FF]"
              />
            </div>
          ))}
        </div>
      </div>

      <div className="flex items-center gap-3 pt-2">
        <button
          onClick={() => router.back()}
          type="button"
          className="px-5 py-2.5 rounded-xl border border-[#E2E8F0] bg-white text-[1rem] font-medium cursor-pointer"
        >
          Cancel
        </button>

        <button
          type="submit"
          className="px-5 py-2.5 rounded-xl bg-brand-primary text-white text-[1rem] font-medium cursor-pointer"
        >
          Send Invitation
        </button>
      </div>
    </form>
  );
}
