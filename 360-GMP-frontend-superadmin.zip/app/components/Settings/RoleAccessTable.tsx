"use client";

import { FiEdit, FiTrash2 } from "react-icons/fi";
import { TableRowData } from "@/types";
import DataTable, { Column } from "../common/DataTable";
import DeleteRoleModal from "./DeleteRoleModal";
import { useState } from "react";

const data: TableRowData[] = [
  {
    id: "1",
    name: "Muhammad Umair",
    email: "umairstack.dev@gmail.com",
    moduleAccess: "5 Modules",
    status: true,
  },
  {
    id: "2",
    name: "Ali Khan",
    email: "ali@gmail.com",
    moduleAccess: "3 Modules",
    status: true,
  },
];

export default function RoleAccessTable() {
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [selectedRoleId, setSelectedRoleId] = useState<string | null>(null);

  const handleDeleteClick = (id: string) => {
    setSelectedRoleId(id);
    setIsDeleteModalOpen(true);
  };

  const columns: Column<TableRowData>[] = [
    {
      key: "name",
      header: "Role Name",
      render: (row) => (
        <div className="flex flex-col">
          <span className="text-[1rem] font-medium">{row.name}</span>
          <span className="mt-0.5 text-sm text-text-hint">{row.email}</span>
        </div>
      ),
    },
    {
      key: "moduleAccess",
      header: "Module Access",
      render: (row) => (
        <span className="inline-block rounded-md bg-brand-btn-pills-background px-3 py-1 text-xs font-semibold text-brand-btn-pills">
          {row.moduleAccess}
        </span>
      ),
    },
    {
      key: "action",
      header: "Action",
      align: "center",
      render: (row) => (
        <div className="flex items-center justify-center gap-4">
          <button className="text-text-secondary hover:text-text-primary transition-colors duration-150">
            <FiEdit />
          </button>
          <button
            onClick={() => handleDeleteClick(row.id)}
            className="text-accent-danger transition hover:text-red-700"
          >
            <FiTrash2 />
          </button>
        </div>
      ),
    },
  ];

  return (
    <>
      <DataTable columns={columns} data={data} rowKey={(row) => row.id} />;
      {isDeleteModalOpen && (
        <DeleteRoleModal
          isOpen={isDeleteModalOpen}
          onClose={() => setIsDeleteModalOpen(false)}
        />
      )}
    </>
  );
}
