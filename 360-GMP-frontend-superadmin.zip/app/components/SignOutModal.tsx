import React from 'react';
import { FiPower } from 'react-icons/fi'; 


interface SignOutModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
}

const SignOutModal: React.FC<SignOutModalProps> = ({ isOpen, onClose, onConfirm }) => {
  if (!isOpen) return null;

  return (
  
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/40 backdrop-blur-[2px] transition-opacity duration-300">
      
  
      <div 
        className="bg-white rounded-[20px] shadow-2xl w-[90%] max-w-[400px] p-6 text-center transform transition-all duration-300 scale-100 opacity-100"
      >
       
        <div className="mx-auto flex h-[72px] w-[72px] items-center justify-center rounded-full bg-[#FFEBEF] mb-4">
          <div className="flex h-[48px] w-[48px] items-center justify-center rounded-full bg-accent-danger text-white shadow-sm">
            <FiPower className="text-2xl stroke-[3]" />
          </div>
        </div>


        <h2 className="text-lg font-bold text-gray-900 mb-3">
          Sign Out Account
        </h2>

        <p className="text-sm text-gray-500 mb-6 leading-relaxed px-2">
          Are you sure you want to log out of the <br className="hidden sm:block" />
          360GMP Admin Portal? You will need to re- <br className="hidden sm:block" />
          authenticate to access the dashboard.
        </p>

        
        <hr className="border-gray-100 mb-6" />

        
        <div className="flex items-center gap-4">
          <button
            onClick={onClose}
            className="flex-1 rounded-xl border border-gray-200 bg-white py-3 text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors duration-200 cursor-pointer"
          >
            No
          </button>
          <button
            onClick={onConfirm}
            className="flex-1 rounded-xl bg-accent-danger py-3 text-sm font-medium text-white hover:bg-accent-danger-light shadow-sm transition-colors duration-200 cursor-pointer"
          >
            Yes
          </button>
        </div>
      </div>
    </div>
  );
};

export default SignOutModal;