import LoginPage from "@/app/components/Layouts/Login/Login";


export default function page() {
 

  return (
   <>
   <LoginPage/>
   </>
  );
}