"use client";
import { useRouter } from "next/navigation";
import { IoShieldCheckmarkOutline } from "react-icons/io5";

interface Props {
  id: string;
  subscriptionManagement: string;
}

export default function SubscriptionTableActions({ id, subscriptionManagement }: Props) {
  const router = useRouter();

 const handleViewAccount = () => {
  console.log("subscriptionManagement:", subscriptionManagement);
  console.log("id:", id);

  if (subscriptionManagement === "SubscriptionManagementUsersTable") {
    router.push(`/subscription/view-subscription-free-trial-information/${id}`);
  } else {
    router.push(`/subscription/view-subscription-paid-information/${id}`);
  }
};

  return (
    <>
      <div className="flex items-center justify-center gap-4">
        <button
          onClick={handleViewAccount}
          className="flex items-center gap-2 rounded-lg border border-[#0B8806] bg-[#E6F6E9] px-5 py-1.5 text-[#0B8806] transition-colors hover:bg-[#D8F2DD] cursor-pointer"
        >
          Preview <IoShieldCheckmarkOutline className="w-5 h-5" />
        </button>
      </div>

    </>
  );
}
