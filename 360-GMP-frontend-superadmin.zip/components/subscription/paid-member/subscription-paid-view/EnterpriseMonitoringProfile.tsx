"use client";

import React from "react";
import Image from "next/image";
import { HiOutlineMail } from "react-icons/hi";
import { IoLocationOutline } from "react-icons/io5";
import { RiCornerLeftDownLine, RiShieldLine } from "react-icons/ri";
import { FaCrown } from "react-icons/fa6";

export default function EnterpriseMonitoringProfile() {
  return (
    <div className="p-[1.5rem] bg-white font-sans flex flex-col gap-[1.5rem] border border-gray-200 rounded-[0.75rem] shadow-sm">
      <div className="flex items-center justify-between">
        <div className="flex flex-col gap-[0.25rem]">
          <h1 className="text-[1.25rem] font-bold text-[#1e293b]">
            Global Manufacturing Co.
          </h1>
          <p className="text-[0.875rem] text-[#64748b]">
            detailed view of global manufacturing co.
          </p>
        </div>

        <div className="flex items-center gap-[0.375rem] px-[1.5rem] py-[0.35rem]  text-[#7c3aed] text-[0.8125rem] font-semibold rounded-full border border-[#e9d5ff]">
          <span className="text-[1.125rem]">Enterprise</span>
          <FaCrown className="w-[0.875rem] h-[0.875rem]" />
        </div>
      </div>

      <div className="flex items-center justify-between p-[1rem] bg-[#f8fafc] border border-gray-200 rounded-[0.5rem]">
        <div className="flex items-center gap-[1rem]">
          <div className="relative w-[3.5rem] h-[3.5rem] rounded-[0.5rem] overflow-hidden border border-gray-200 bg-white flex items-center justify-center shadow-xs">
            <Image
              src="/images/image 55.png"
              alt="Global Manufacturing Co."
              fill
              className="object-cover"
            />
          </div>

          <div className="flex flex-col gap-[0.25rem]">
            <h2 className="text-[1rem] font-semibold text-[#1e293b]">
              Global Manufacturing Co.
            </h2>
            <div className="flex items-center gap-[0.75rem] text-[0.875rem] text-[#64748b]">
              <div className="flex items-center gap-[0.375rem]">
                <HiOutlineMail className="w-[1rem] h-[1rem] text-gray-400" />
                <span>globalmanufacturing@gmail.com</span>
              </div>
              <span className="w-[0.25rem] h-[0.25rem] bg-gray-400 rounded-full" />
              <div className="flex items-center gap-[0.375rem]">
                <IoLocationOutline className="w-[1rem] h-[1rem] text-gray-400" />
                <span>Los Angles USA</span>
              </div>
            </div>
          </div>
        </div>

        <button
          onClick={() => alert("Contacting Global Manufacturing Co....")}
          className="flex items-center gap-[0.5rem] px-[1.25rem] py-[0.625rem] bg-[#2c0a59] hover:bg-[#1d053b] text-white font-medium text-[1rem] rounded-[0.5rem] transition-colors cursor-pointer shadow-sm"
        >
          <span>Contact</span>
          <HiOutlineMail className="w-[1rem] h-[1rem]" />
        </button>
      </div>

      <div className="border border-gray-200 rounded-[0.5rem] p-[1.5rem] bg-white flex flex-col gap-[0.5rem]">
        <span className="text-[1rem] text-[#64748b] font-medium">
          Life Time Value
        </span>
        <h3 className="text-[2rem] font-bold text-[#1e293b] tracking-tight">
          $4,200.00
        </h3>
        <p className="text-[0.8125rem] text-[#64748b] pt-[0.25rem]">
          Total Collected Reenue Since 2021
        </p>
      </div>

      <div className="border border-gray-200 rounded-[0.6rem] overflow-hidden bg-white">
        <div className="px-[1.5rem] py-[1rem] bg-[#2c0a59]">
          <h3 className="text-[1.375rem] font-semibold text-white">
            Current Plan
          </h3>
        </div>

        <div className="p-[2.0rem] flex flex-col items-center justify-center gap-[1rem] text-center bg-white">
          <div className="flex items-center justify-center w-[3rem] h-[3rem] rounded-full bg-[#f5effa] text-[#7c3aed]">
            <RiShieldLine className="w-[1.5rem] h-[1.5rem]" />
          </div>

          <div className="flex flex-col gap-[0.25rem]">
            <h4 className="text-[1.125rem] font-bold text-[#1e293b]">
              Enterprise Active
            </h4>
            <p className="text-[0.875rem] text-[#64748b]">
              This user has unlimited access to all features.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
