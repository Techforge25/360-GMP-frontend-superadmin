"use client";

import { useEffect, useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { FiSearch, FiChevronDown, FiChevronUp } from "react-icons/fi";

interface FormValues {
  search: string;
  filter: string;
}

interface Props {
  placeholder?: string;
  dropdownOptions?: string[];
  defaultFilter?: string;
  debounceTime?: number;
  onSearch?: (value: string) => void;
  onFilterChange?: (value: string) => void;
}

export default function SearchFilterBar({
  placeholder = "Search Users...",
  dropdownOptions = [],
  defaultFilter = "",
  debounceTime = 500,
  onSearch,
  onFilterChange,
}: Props) {
  const [open, setOpen] = useState(false);

  const { register, watch, control } = useForm<FormValues>({
    defaultValues: {
      search: "",
      filter: defaultFilter,
    },
  });

  const searchValue = watch("search");

  useEffect(() => {
    const timer = setTimeout(() => {
      onSearch?.(searchValue);
    }, debounceTime);

    return () => clearTimeout(timer);
  }, [searchValue, debounceTime, onSearch]);

  return (
    <div className="flex w-full items-center justify-between gap-4">
      <div className="relative w-full max-w-[24.25rem]">
        <FiSearch className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-[#768299]" />

        <input
          {...register("search")}
          placeholder={placeholder}
          className="search-filter"
        />
      </div>

      {dropdownOptions.length > 0 && (
        <Controller
          name="filter"
          control={control}
          render={({ field }) => (
            <div className="relative w-[10.625rem]">
              <button
                type="button"
                onClick={() => setOpen(!open)}
                className="flex h-[2.75rem] w-full items-center justify-between rounded-lg border border-[#D7DFEC] bg-white px-4 text-sm font-medium text-[#111827]"
              >
                {field.value || dropdownOptions[0]}

                {open ? <FiChevronUp /> : <FiChevronDown />}
              </button>

              {open && (
                <div className="absolute top-[3rem] z-50 w-full overflow-hidden rounded-lg border border-[#E2E8F0] bg-white shadow-lg">
                  {dropdownOptions.map((item) => (
                    <button
                      key={item}
                      type="button"
                      onClick={() => {
                        field.onChange(item);
                        onFilterChange?.(item);
                        setOpen(false);
                      }}
                      className={`flex w-full items-center border-b border-[#E2E8F0] px-3 py-3 text-left text-sm text-[#111827] last:border-none hover:bg-[#F8F5FF]
                      ${field.value === item ? "bg-[#F8F5FF]" : "bg-white"}`}
                    >
                      {item}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        />
      )}
    </div>
  );
}
