"use client";
import DataTable, { Column } from "@/components/common/DataTable";
import { TableRowData, TypeCreateAdmin } from "@/types";
import RoleTableActions from "./RoleTableActions";


const columns: Column<TableRowData>[] = [
  {
    key: "name",
    header: "Role Name",
    render: (row) => {
      return (
        <div className="flex flex-col">
          <span className="text-[1rem] font-medium">{row?.name}</span>

          <span className="mt-0.5 text-sm text-gray-600">{row?.email}</span>
        </div>
      );
    },
  },

  {
    key: "allowedModules",
    header: "Module Access",
    render: (row) => {
      return (
        <div className="flex flex-wrap gap-2">
          {row?.allowedModules?.map((module, index) => (
            <span key={index} className="roles-status">
              {module}
            </span>
          ))}
        </div>
      );
    },
  },

  {
    key: "action",
    header: "Action",
    align: "center",
    render: (row) => {
      console.log("Action Column:", row);
      return <RoleTableActions id={row?._id} name={row?.name} />;
    },
  },
];

interface Props {
  adminData: TypeCreateAdmin;
  isFetching: boolean;
}


export default function RoleAccessTable({ adminData, isFetching }: Props) {
  return (
    <DataTable
      columns={columns}
      data={adminData}
      rowKey={(row) => row._id}
      isLoading={isFetching}
    />
  );
}
