import RevenueGraph from "@/components/Dashboard/RevenueGraph";
import SubscriptionGraph from "@/components/Dashboard/SubscriptionGraph";
import { dashboardCard } from "@/constants/dashboard/dashboardOverview";
import OverviewCards from "../common/OverviewCards";
import NewBusinessTable from "./BusinessTable/NewBusinessTable";

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-[#fafafc] p-6 md:p-4 font-sans">
      <OverviewCards
        heading="Dashboard Overview"
        className="sm:grid-cols-4 lg:grid-cols-4"
        description="Welcome back john doe"
        cards={dashboardCard}
      />
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-[1.5rem] mt-6">
        <RevenueGraph />
        <SubscriptionGraph />
      </div>
      <NewBusinessTable />
    </div>
  );
}
