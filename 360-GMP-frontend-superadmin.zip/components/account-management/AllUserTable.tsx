import React from "react";
import SearchFilterBar from "../common/SearchFilterBar";
import AccountManagementTable from "./AccountManagementTable";
import Pagination from "../common/Pagination";
import AccountPagination from "@/constants/acount-management/AccountPagination";

export default function AllUserTable() {
    
  return (
    <div className="rounded-2xl border border-border-light bg-white p-6 shadow-sm">
      <SearchFilterBar
        placeholder="Search Business..."
        dropdownOptions={["Free Trial", "Consumer", "Silver", "Gold", "Enterprise"]}
        defaultFilter="All"
        onSearch={(value) => {
          console.log("Business Search:", value);
        }}
        onFilterChange={(value) => {
          console.log("Business Filter:", value);
        }}
      />
      <AccountManagementTable/>
       <AccountPagination/>

    </div>
  );
}
