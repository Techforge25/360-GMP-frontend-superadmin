"use client";

import { useTransition } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { accountManagementTabs } from "@/constants/acount-management/AccountManagementtabs";
import Tabs from "../common/Tabs";
import SearchFilterBar from "../common/SearchFilterBar";
import AllUserTable from "./AllUserTable";

export default function AccountManagement() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [isPending, startTransition] = useTransition();

  const currentTab = searchParams.get("tab") || accountManagementTabs[0]?.id;

  const handleTabChange = (tabId: string) => {
    startTransition(() => {
      router.push(`?tab=${tabId}`, { scroll: false });
    });
  };        

  return (
    <>
      <div className="mt-2">
        <Tabs 
          tabs={accountManagementTabs} 
          activeTab={currentTab} 
          onTabChange={handleTabChange} 
        />
      </div>

      <div className={`mt-6 transition-opacity duration-200 ${isPending ? "opacity-50" : "opacity-100"}`}>
        {currentTab === "all-user" && (
         <AllUserTable/>
        )}

        {currentTab === "all-business" && (
          <div className="bg-white p-6 rounded-2xl border border-border-light shadow-sm">
            <h3 className="text-lg font-semibold text-text-primary mb-4">All Business Table / Content</h3>
          </div>
        )}
      </div>
    </>
  );
}