"use client";

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { FiEdit, FiTrash2 } from "react-icons/fi";
import DeleteRoleModal, {
  DeleteRoleModalRef,
} from "@/components/modal/DeleteRoleModal";
import { IoShieldCheckmarkOutline } from "react-icons/io5";

interface Props {
  id: string;
}


export default function RoleTableActions({ id }: Props) {
  const router = useRouter();

  const deleteModalRef = useRef<DeleteRoleModalRef>(null);

  return (
    <>
      <div className="flex items-center justify-center gap-4">
       <button
  onClick={() => router.push(`/settings/view-admin/${id}`)}
  className="flex items-center gap-2 rounded-lg border border-[#0B8806] bg-[#E6F6E9] px-5 py-1.5 text-[#0B8806] transition-colors hover:bg-[#D8F2DD]"
>
  Preview <IoShieldCheckmarkOutline className="w-5 h-5" />
</button>

      </div>

 
        <DeleteRoleModal
        ref={deleteModalRef}
        onConfirm={() => {
          console.log("Delete:", id);
        }}
      />
 
    </>
  );
}
